import assert from 'node:assert/strict';
import {build} from 'esbuild';
import {readFile, readdir, stat} from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
await build({entryPoints: ['src/lib/catalog.ts'], outfile: '.build/catalog.mjs', bundle: true, platform: 'node', format: 'esm'});
const {events, defaults, matchEvent, readFilters, filtersSearch} = await import(pathToFileURL(path.resolve('.build/catalog.mjs')));
const by = number => events.find(e => e.number === number);
assert.equal(events.length, 225);
assert.equal(new Set(events.map(e => e.id)).size, 225);
assert.equal(matchEvent(by(32), {...defaults, age:'3', metro:'Чернышевская', from:'2027-01-05', to:'2027-01-05'}), 'match');
assert.equal(matchEvent(by(33), {...defaults, age:'3', from:'2027-01-05', to:'2027-01-05'}), false);
assert.equal(matchEvent(by(50), {...defaults, age:'3', from:'2026-12-25', to:'2026-12-25'}), 'uncertain');
assert.equal(matchEvent(by(1), {...defaults, age:'1'}), 'uncertain');
assert.equal(matchEvent(by(222), {...defaults}), 'match');
assert.equal(matchEvent(by(98), {...defaults}), false);
const filters = {...defaults, age:'3', metro:'Чернышевская', from:'2027-01-05', to:'2027-01-05'};
assert.deepEqual(readFilters(filtersSearch(filters)), filters);
assert.ok(!Object.keys(defaults).some(key => /price|budget/i.test(key)));
assert.ok(events.every(e => new URL(e.ticketUrl).protocol === 'https:'));
async function files(directory) {
  const entries = await readdir(directory, {withFileTypes: true});
  return (await Promise.all(entries.map(entry => entry.isDirectory() ? files(path.join(directory,entry.name)) : path.join(directory,entry.name)))).flat();
}
const all = await files('dist');
const htmlFiles = all.filter(file => file.endsWith('.html'));
assert.equal(htmlFiles.length, 229);
const home = await readFile('dist/index.html', 'utf8');
const base = home.match(/<script type="module" src="([^"]+)app\.js"/)[1];
for (const filename of htmlFiles) {
  const html = await readFile(filename, 'utf8');
  assert.ok(html.includes('https://t.me/friendlymap'), filename + ': missing channel');
  assert.ok(!html.includes('chatgpt.site') && !html.includes('/api/track') && !html.includes('href="/stats"'), filename + ': runtime dependency');
  for (const match of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const value = match[1].replace(/&amp;/g, '&');
    if (value.startsWith('https:') || value.startsWith('#') || value.startsWith('data:')) continue;
    assert.ok(value.startsWith(base), filename + ': link outside base: ' + value);
    const suffix = decodeURIComponent(value.slice(base.length).split(/[?#]/)[0]);
    let local = path.join('dist', suffix);
    if (!suffix || suffix.endsWith('/')) local = path.join(local, 'index.html');
    assert.ok((await stat(local)).isFile(), filename + ': missing target: ' + value);
  }
}
for (const e of events) {
  const html = await readFile(`dist/event/${e.id}/index.html`, 'utf8');
  assert.ok(html.includes('Билеты и стоимость') && html.includes('Источник информации'));
}
console.log('Verified 225 events, combined filters, uncertain dates and ages, price independence, 229 static pages, and all local links and assets.');
