import {hydrateRoot} from 'react-dom/client';
import {pageFor} from './routes';
hydrateRoot(document.getElementById('root')!, pageFor(document.documentElement.dataset.route || '/404/'));
