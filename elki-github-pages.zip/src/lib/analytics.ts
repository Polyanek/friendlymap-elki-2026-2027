export type TrackKind = 'page_view'|'event_view'|'ticket_click'|'telegram_header_click'|'telegram_footer_click'|'filters_apply'|'zero_results'|'share_click';
declare const __METRIKA_COUNTER_ID__: number;
declare global { interface Window { ym?: ((...args: any[]) => void) & {a?: any[]; l?: number}; } }
export const analyticsConfigured = __METRIKA_COUNTER_ID__ > 0;
let initialized = false;
function allowed() {
  if (!analyticsConfigured || typeof window === 'undefined' || navigator.doNotTrack === '1') return false;
  try { return localStorage.getItem('friendlymap.analytics') !== 'off'; } catch { return false; }
}
export function track(kind: TrackKind, target = 'catalog') {
  if (!allowed()) return;
  try {
    if (!initialized) {
      window.ym ||= Object.assign(function (...args: any[]) { window.ym!.a!.push(args); }, {a: [] as any[], l: Date.now()});
      const script = document.createElement('script');
      script.async = true;
      script.src = 'https://mc.yandex.ru/metrika/tag.js';
      document.head.appendChild(script);
      window.ym(__METRIKA_COUNTER_ID__, 'init', {defer: true, webvisor: false, clickmap: false, trackLinks: false, accurateTrackBounce: true});
      initialized = true;
    }
    if (kind === 'page_view') {
      // Exclude search terms and filter parameters from the reported page URL.
      const cleanReferrer = document.referrer ? new URL(document.referrer).origin : '';
      window.ym!(__METRIKA_COUNTER_ID__, 'hit', location.origin + location.pathname, {title: document.title, referer: cleanReferrer});
    } else {
      window.ym!(__METRIKA_COUNTER_ID__, 'reachGoal', kind, {event_id: target});
    }
  } catch { /* Analytics must not interrupt choosing an event. */ }
}
