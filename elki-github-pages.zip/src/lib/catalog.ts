import records from '../data/catalog.json';
export type EventRecord={id:string;number:number;title:string;venue:string;region:string;locality:string;address:string|null;district:string|null;metro:string[];placeTypes:string[];formats:string[];ageText:string;ageMin:number|null;ageMax:number|null;ageKind:string;datesText:string;exactDates:string[];dateStart:string|null;dateEnd:string|null;dateKind:string;sessionsText:string;priceText:string;priceShort:string;status:'family'|'group'|'announcement'|'soldout';checkedAt:string;ticketUrl:string;sourceUrls:string[];description:string;notes:string[]};
export const events=records as EventRecord[];
export const places:Record<string,string>={palace:'Дворцы и особняки',theatre:'Театры',museum:'Музеи',kids_space:'Детские пространства',restaurant:'Рестораны и кафе',culture_center:'ДК и культурные центры',concert_hall:'Концертные залы',arena:'Арены',circus:'Цирк',nature:'Природа и загород',factory:'Фабрики',ship:'Корабли',greenhouse:'Оранжереи',hotel:'Отели',other:'Другие площадки'};
export const formats:Record<string,string>={performance:'Спектакль / мюзикл',interactive:'Интерактив / квест',ball:'Бал',concert:'Концерт',science:'Научная программа',workshop:'Мастер-класс',circus_show:'Цирковое шоу',ice_show:'Ледовое шоу',water_show:'Водное шоу',tour:'Экскурсия',baby:'Бэби-программа',other:'Другой формат'};
export const statuses={family:'Семейное посещение',group:'Для организованных групп',announcement:'Анонс / условия уточняются',soldout:'Распродано у проверенного продавца'};
export type Filters={q:string;age:string;region:string;district:string;metro:string;place:string;format:string;from:string;to:string;status:string;uncertain:boolean;favorites:boolean;sort:string};
export const defaults:Filters={q:'',age:'',region:'',district:'',metro:'',place:'',format:'',from:'',to:'',status:'family',uncertain:false,favorites:false,sort:'selection'};
const norm=(v:string)=>v.toLowerCase().replace(/ё/g,'е');
export function matchEvent(e:EventRecord,f:Filters,favs:string[]=[]):'match'|'uncertain'|false{
 if(f.q&&!norm([e.title,e.venue,e.address,e.district,...e.metro].join(' ')).includes(norm(f.q)))return false;
 if(f.status!=='all'&&e.status!==f.status)return false;
 if(f.region&&e.region!==f.region)return false;
 if(f.district&&e.district!==f.district)return false;
 if(f.metro&&!e.metro.includes(f.metro))return false;
 if(f.place&&!e.placeTypes.includes(f.place))return false;
 if(f.format&&!e.formats.includes(f.format))return false;
 if(f.favorites&&!favs.includes(e.id))return false;
 let unsure=false;
 if(f.age){
  const age=Number(f.age);
  if(e.ageMin===null||e.ageKind!=='recommended')unsure=true;
  else if(age===0){if(e.ageMin>=1)return false;}
  else if(age<e.ageMin||(e.ageMax!==null&&age>e.ageMax))return false;
 }
 if(f.from||f.to){
  const from=f.from||'2026-11-01',to=f.to||'2027-02-28';
  const explicit=e.exactDates.some(x=>x>=from&&x<=to);
  if(!explicit){
   if(e.dateKind==='exact')return false;
   if(e.dateStart&&e.dateEnd&&(e.dateEnd<from||e.dateStart>to))return false;
   unsure=true;
  }
 }
 return unsure?'uncertain':'match';
}
export function readFilters(search:string):Filters{
 const p=new URLSearchParams(search);const out={...defaults};
 for(const k of Object.keys(defaults) as (keyof Filters)[]){const v=p.get(k);if(v===null)continue;if(k==='uncertain'||k==='favorites')out[k]=v==='1';else (out as any)[k]=v.slice(0,150);}
 if(!['family','group','announcement','soldout','all'].includes(out.status))out.status='family';
 if(out.age&&!/^(?:[0-9]|1[0-4])$/.test(out.age))out.age='';
 for(const k of ['from','to'] as const)if(out[k]&&!/^202[67]-\d{2}-\d{2}$/.test(out[k]))out[k]='';
 return out;
}
export function filtersSearch(f:Filters){const p=new URLSearchParams();for(const k of Object.keys(defaults) as (keyof Filters)[]){if(f[k]!==defaults[k]&&f[k]!==''&&f[k]!==false)p.set(k,typeof f[k]==='boolean'?'1':String(f[k]));}const str=p.toString();return str?'?'+str:'';}
export const dateLabel=(d:string)=>new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long'}).format(new Date(d+'T12:00:00'));
export function displayDates(e:EventRecord){
 if(!/\b202[67]-\d{2}-\d{2}\b/.test(e.datesText))return e.datesText;
 if(e.dateKind==='exact'&&e.exactDates.length){
  const groups=new Map<string,string[]>();
  for(const d of e.exactDates){const k=d.slice(0,7);groups.set(k,[...(groups.get(k)||[]),String(Number(d.slice(8)))]);}
  return [...groups].map(([month,days])=>{const sample=new Date(month+'-01T12:00:00');const name=new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long',year:'numeric'}).format(sample).replace(/^1 /,'');const dayText=days.length>1?days.slice(0,-1).join(', ')+' и '+days[days.length-1]:days[0];return dayText+' '+name;}).join('; ');
 }
 return e.datesText.replace(/202[67]-\d{2}-\d{2}/g,d=>new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long',year:'numeric'}).format(new Date(d+'T12:00:00')));
}
