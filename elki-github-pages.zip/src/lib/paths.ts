declare const __SITE_BASE__: string;
export const siteBase = __SITE_BASE__;
export const sitePath = (path: string) => siteBase + path.replace(/^\//, '');
