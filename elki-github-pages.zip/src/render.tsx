import {renderToString} from 'react-dom/server';
import {pageFor} from './routes';
export const render = (route: string) => renderToString(pageFor(route));
