import Catalog from './app/catalog';
import EventDetail from './app/event/[id]/event-detail';
import About from './app/about/page';
import Privacy from './app/privacy/page';
import {Header, Footer} from './app/components';
import {events} from './lib/catalog';
import {sitePath} from './lib/paths';
export function pageFor(route: string) {
  if (route === '/') return <Catalog/>;
  if (route === '/about/') return <About/>;
  if (route === '/privacy/') return <Privacy/>;
  const event = events.find(e => route === `/event/${e.id}/`);
  if (event) return <EventDetail event={event}/>;
  return <><Header/><main className="shell simple-main"><h1>Страница не найдена</h1><p>Выберите праздник в каталоге новогодних событий.</p><a className="primary" href={sitePath('/')}>Открыть подборку</a></main><Footer/></>;
}
